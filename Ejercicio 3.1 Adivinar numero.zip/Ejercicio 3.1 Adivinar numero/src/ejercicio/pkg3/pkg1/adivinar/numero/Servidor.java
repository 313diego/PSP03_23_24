/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3.pkg1.adivinar.numero;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 *
 * @author diego
 */
public class Servidor {
    
    final int puerto = 3000;
    static final int numRandom = (int) (Math.floor(Math.random() * (500 - 0 + 1)));
    int numRecibido;
    String recibido;
    String adivinado = "Enhorabuena, has adivinado el número";
    String mayor = "El número es mayor";
    String menor = "El número es menor";

    public Servidor() {

        try {
            ServerSocket servidor = new ServerSocket(puerto);
            System.out.println("Escuchando el puerto " + puerto);
            Socket sCliente = servidor.accept();
            System.out.println("El cliente se ha conectado");
            DataInputStream in = new DataInputStream(sCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(sCliente.getOutputStream());
            while (true) {
                recibido = in.readUTF();
                System.out.println("El cliente ha dicho " + recibido);
                numRecibido = Integer.parseInt(recibido);
                if (numRecibido == numRandom) {
                    out.writeUTF(adivinado);
                    sCliente.close();
                    System.out.println("El cliente se ha desconectado");
                    break;
                } else if (numRecibido < numRandom) {
                    out.writeUTF(mayor);
                }else{
                    out.writeUTF(menor);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static void main(String[] args) {
        new Servidor();
    }

}
